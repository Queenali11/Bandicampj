mvn validate -Pbenchmarkscore -Dexec.args="expectedresults-1.2beta.csv results none anonymous"
