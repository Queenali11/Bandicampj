mvn clean package cargo:run -PdeployseczoneIAST
